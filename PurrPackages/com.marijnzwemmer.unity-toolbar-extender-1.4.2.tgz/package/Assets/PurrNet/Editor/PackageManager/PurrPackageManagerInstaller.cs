using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEditor;
using UnityEngine;

namespace PurrNet.Editor
{
    public static class PurrPackageManagerInstaller
    {
        private const string LegacyPackagesDir = "PurrPackages";
        private const string ManifestPath = "Packages/manifest.json";
        private const string LockFilePath = "Packages/packages-lock.json";

        // The package-manager window re-queries install state on every OnGUI repaint — once per
        // package row, plus the "Update All" count — and each query parsed manifest.json /
        // packages-lock.json from disk. Parsing a ~500-line JSON document dozens of times per frame
        // was the bulk of the window's CPU/GC cost, so the parsed forms are cached and invalidated
        // by file modification time (and explicitly after our own writes).
        private static JObject _cachedManifest;
        private static DateTime _cachedManifestMtime;
        private static JObject _cachedLockFile;
        private static DateTime _cachedLockFileMtime;

        private static JObject ReadJsonCached(string path, ref JObject cache, ref DateTime cacheMtime)
        {
            if (!File.Exists(path))
            {
                cache = null;
                return null;
            }

            var mtime = File.GetLastWriteTimeUtc(path);
            if (cache != null && mtime == cacheMtime)
                return cache;

            try
            {
                cache = JObject.Parse(File.ReadAllText(path));
                cacheMtime = mtime;
            }
            catch
            {
                cache = null;
            }
            return cache;
        }

        private static JObject GetManifestJson() => ReadJsonCached(ManifestPath, ref _cachedManifest, ref _cachedManifestMtime);
        private static JObject GetLockFileJson() => ReadJsonCached(LockFilePath, ref _cachedLockFile, ref _cachedLockFileMtime);

        private static void InvalidateFileCaches()
        {
            _cachedManifest = null;
            _cachedLockFile = null;
        }

        /// <summary>
        /// Snapshot of Packages/manifest.json and packages-lock.json taken before an install/remove
        /// touches them. If the operation throws partway (download failure, a locked PackageCache
        /// folder Unity can't delete during resolve, a failed file sync, ...) the snapshot is restored
        /// so the project is never left without the package it had before.
        /// </summary>
        private readonly struct ManifestBackup
        {
            private readonly string _manifest;
            private readonly bool _hadManifest;
            private readonly string _lock;
            private readonly bool _hadLock;

            private ManifestBackup(string manifest, bool hadManifest, string lockFile, bool hadLock)
            {
                _manifest = manifest;
                _hadManifest = hadManifest;
                _lock = lockFile;
                _hadLock = hadLock;
            }

            public static ManifestBackup Capture()
            {
                bool hadManifest = File.Exists(ManifestPath);
                bool hadLock = File.Exists(LockFilePath);
                return new ManifestBackup(
                    hadManifest ? File.ReadAllText(ManifestPath) : null, hadManifest,
                    hadLock ? File.ReadAllText(LockFilePath) : null, hadLock);
            }

            public void Restore()
            {
                try
                {
                    if (_hadManifest && _manifest != null && File.ReadAllText(ManifestPath) != _manifest)
                        File.WriteAllText(ManifestPath, _manifest);
                    if (_hadLock && _lock != null && (!File.Exists(LockFilePath) || File.ReadAllText(LockFilePath) != _lock))
                        File.WriteAllText(LockFilePath, _lock);
                    InvalidateFileCaches();
                }
                catch (Exception e)
                {
                    Debug.LogError($"[PurrNet] Failed to restore manifest after a failed package operation: {e.Message}");
                }
            }
        }

        public static bool IsInstalled(PackageInfo package)
        {
            return FindInstalledEntry(package) != null;
        }

        public static string GetInstalledVersion(PackageInfo package)
        {
            var match = FindInstalledEntry(package);
            if (match == null)
                return null;

            var value = match.Value.value;
            var key = match.Value.key;

            // Git URL entries — prefer the version tag baked into the manifest URL (#vX.Y.Z).
            // It's written synchronously by Install() and is the source of truth, unlike
            // Library/PackageCache which Unity only updates after an async resolve — reading
            // it right after a (batch) update yields a stale @oldhash folder.
            if (IsGitUrl(value))
            {
                var tagVersion = GetVersionFromGitUrlRef(value);
                if (tagVersion != null)
                    return tagVersion;

                var resolved = GetResolvedPackageVersion(key, GetInstalledCommitHash(package));
                return resolved ?? "git";
            }

            // Parse version from the entry value
            // Format: "embedded:{name}-{version}" (current), or legacy "file:../PurrPackages/{name}-{version}.tgz" / "file:../PurrPackages/{name}-{version}"
            string nameAndVersion;
            if (value.StartsWith("embedded:"))
                nameAndVersion = value.Substring("embedded:".Length);
            else if (value.EndsWith(".tgz"))
                nameAndVersion = Path.GetFileNameWithoutExtension(value);
            else
                nameAndVersion = Path.GetFileName(value);

            if (nameAndVersion.StartsWith(key + "-"))
                return nameAndVersion[(key.Length + 1)..];
            return null;
        }

        /// <summary>
        /// Returns true if the package is currently installed via a git URL
        /// (either in manifest.json or resolved by Unity).
        /// </summary>
        public static bool IsInstalledViaGit(PackageInfo package)
        {
            var match = FindInstalledEntry(package);
            if (match == null)
                return false;
            return IsGitUrl(match.Value.value);
        }

        /// <summary>
        /// Reads the resolved commit hash from packages-lock.json for a git-installed package.
        /// Uses the actual manifest key (which may differ from GetUpmPackageName).
        /// </summary>
        public static string GetInstalledCommitHash(PackageInfo package)
        {
            var lockFile = GetLockFileJson();
            if (lockFile == null)
                return null;

            // Use the actual installed key, which may differ from apiName
            // when the package was matched by git URL scanning.
            var match = FindInstalledEntry(package);
            var lookupName = match?.key ?? package.GetUpmPackageName();

            try
            {
                var deps = lockFile["dependencies"] as JObject;
                var entry = deps?[lookupName] as JObject;
                if (entry == null)
                    return null;

                var source = entry["source"]?.ToString();
                if (source != "git")
                    return null;

                return entry["hash"]?.ToString();
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Finds the installed entry for a package. Checks embedded packages in Packages/{name}/,
        /// manifest entries (git URLs), and legacy PurrPackages/ file: references.
        /// </summary>
        private static (string key, string value)? FindInstalledEntry(PackageInfo package)
        {
            var apiName = package.GetUpmPackageName();

            // Check for embedded package first (Packages/{name}/ takes priority in Unity)
            if (HasEmbeddedPackage(apiName))
            {
                var pkgJsonPath = Path.Combine("Packages", apiName, "package.json");
                try
                {
                    var json = JObject.Parse(File.ReadAllText(pkgJsonPath));
                    var ver = json["version"]?.ToString() ?? "0.0.0";
                    return (apiName, $"embedded:{apiName}-{ver}");
                }
                catch
                {
                    return (apiName, $"embedded:{apiName}-0.0.0");
                }
            }

            var manifest = GetManifestJson();
            var deps = manifest?["dependencies"] as JObject;
            if (deps == null)
                return null;

            // Try direct lookup with API-provided name
            var directEntry = deps[apiName]?.ToString();
            if (directEntry != null && directEntry.Contains(LegacyPackagesDir))
                return (apiName, directEntry);

            // Check for git URL entries (external packages)
            if (directEntry != null && IsGitUrl(directEntry))
                return (apiName, directEntry);

            // API name may differ from the real name in package.json.
            // Scan legacy entries pointing to PurrPackages/ — this is safe because only our
            // installer puts tarballs there, unlike Packages/ which has unrelated packages.
            if (package.Versions != null && package.Versions.Length > 0)
            {
                foreach (var prop in deps.Properties())
                {
                    var val = prop.Value.ToString();
                    if (!val.Contains(LegacyPackagesDir))
                        continue;

                    // Legacy: val is "file:../PurrPackages/{key}-{version}.tgz" or "file:../PurrPackages/{key}-{version}"
                    var filename = val.EndsWith(".tgz") ? Path.GetFileNameWithoutExtension(val) : Path.GetFileName(val);
                    if (!filename.StartsWith(prop.Name + "-"))
                        continue;

                    var fileVersion = filename[(prop.Name.Length + 1)..];
                    foreach (var v in package.Versions)
                    {
                        if (v.Version == fileVersion)
                            return (prop.Name, val);
                    }
                }
            }

            // Scan manifest for git URLs matching the package's known git URLs.
            // This handles cases where the UPM name differs or the user installed
            // via Unity's Package Manager using the same repo URL.
            if (!string.IsNullOrEmpty(package.GitInstallUrlRelease) || !string.IsNullOrEmpty(package.GitInstallUrlDev))
            {
                var knownBaseUrls = new HashSet<string>();
                if (!string.IsNullOrEmpty(package.GitInstallUrlRelease))
                    knownBaseUrls.Add(GetBaseGitUrl(package.GitInstallUrlRelease));
                if (!string.IsNullOrEmpty(package.GitInstallUrlDev))
                    knownBaseUrls.Add(GetBaseGitUrl(package.GitInstallUrlDev));

                foreach (var prop in deps.Properties())
                {
                    var val = prop.Value.ToString();
                    if (!IsGitUrl(val))
                        continue;

                    if (knownBaseUrls.Contains(GetBaseGitUrl(val)))
                        return (prop.Name, val);
                }
            }

            return null;
        }

        private static bool HasEmbeddedPackage(string upmName)
        {
            var path = Path.Combine("Packages", upmName);
            if (!Directory.Exists(path))
                return false;

            // Unity also creates this folder for tgz/file: installs.
            // Only consider it embedded if there's no file: reference in the manifest.
            var deps = GetManifestJson()?["dependencies"] as JObject;
            var entry = deps?[upmName]?.ToString();
            if (entry != null && (entry.StartsWith("file:") || IsGitUrl(entry)))
                return false;

            return true;
        }

        /// <summary>
        /// Removes a directory by moving it to Temp/ first, then best-effort deleting it.
        /// Directory.Move within the same volume is a rename, so the original path is
        /// freed up immediately — locked files (e.g. loaded native DLLs) stay in Temp/
        /// and get cleaned up later with the project's Temp folder.
        /// </summary>
        private static void SafeRemoveDirectory(string path)
        {
            if (!Directory.Exists(path))
                return;

            Directory.CreateDirectory("Temp");
            var tempDest = Path.Combine("Temp", "PurrNet_cleanup_" + DateTime.Now.Ticks);
            Directory.Move(path, tempDest);

            try
            {
                Directory.Delete(tempDest, true);
            }
            catch
            {
                // Locked files remain in Temp/ — not our problem anymore, original path is free
            }
        }

        /// <summary>
        /// Clears any existing install of <paramref name="package"/> so a new version can be written.
        /// Removes manifest entries, legacy PurrPackages/ files, and embedded Packages/{name}/ folders
        /// for both the detected install key and the canonical name (needed when api name ≠ upm name,
        /// or when a rename crossed versions).
        /// </summary>
        /// <remarks>
        /// Ordering within each name: SafeRemoveDirectory BEFORE CleanupLegacyPackageFiles.
        /// Packages/{name}/ may be a Unity-created junction pointing at PurrPackages/{name}-{version}/.
        /// Deleting the target first leaves the junction dangling and Directory.Exists returns false,
        /// orphaning the junction forever.
        /// </remarks>
        private static void ClearExistingInstall(PackageInfo package, string canonicalName)
        {
            var match = FindInstalledEntry(package);
            if (match != null)
                ClearByName(match.Value.key);

            if (!string.IsNullOrEmpty(canonicalName) && (match == null || match.Value.key != canonicalName))
                ClearByName(canonicalName);

            static void ClearByName(string name)
            {
                RemoveManifestEntry(name);
                SafeRemoveDirectory(Path.Combine("Packages", name));
                CleanupLegacyPackageFiles(name);
            }
        }

        /// <summary>
        /// Installs files from <paramref name="sourceDir"/> into Packages/{canonicalName}/ by
        /// per-file sync: unchanged files are left untouched (critical — prevents Unity from
        /// re-importing / reloading locked native DLLs that didn't actually change), new files
        /// are copied in, and files absent from the source are removed. Also clears manifest
        /// entries and legacy PurrPackages/ files for both the detected install key and the
        /// canonical name so the install is auto-discovered as embedded.
        /// </summary>
        private static void InstallFilesSynced(PackageInfo package, string canonicalName, string sourceDir)
        {
            var targetFolder = Path.Combine("Packages", canonicalName);
            var match = FindInstalledEntry(package);

            RemoveManifestEntry(canonicalName);
            CleanupLegacyPackageFiles(canonicalName);

            // Different-name install (rename or api/upm mismatch) — can't sync across names, full wipe.
            if (match != null && !string.Equals(match.Value.key, canonicalName, StringComparison.OrdinalIgnoreCase))
            {
                RemoveManifestEntry(match.Value.key);
                SafeRemoveDirectory(Path.Combine("Packages", match.Value.key));
                CleanupLegacyPackageFiles(match.Value.key);
            }

            // Unlink junction at target without following it — else sync would write into the
            // legacy PurrPackages/ target rather than replacing the junction with a real folder.
            if (Directory.Exists(targetFolder)
                && (File.GetAttributes(targetFolder) & FileAttributes.ReparsePoint) != 0)
            {
                Directory.Delete(targetFolder, false);
            }

            SyncDirectory(sourceDir, targetFolder);
        }

        /// <summary>
        /// Syncs <paramref name="destination"/> to match <paramref name="source"/>:
        /// copies files that are new or have different content, deletes files not present in source,
        /// and leaves byte-identical files completely untouched. Logs a warning if any file could
        /// not be written or deleted (usually a locked native library — caller should advise a restart).
        /// </summary>
        private static void SyncDirectory(string source, string destination)
        {
            Directory.CreateDirectory(destination);

            var sourceRelPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            int failed = 0;

            foreach (var srcFile in Directory.GetFiles(source, "*", SearchOption.AllDirectories))
            {
                var rel = Path.GetRelativePath(source, srcFile);
                sourceRelPaths.Add(rel);

                var dstFile = Path.Combine(destination, rel);

                if (File.Exists(dstFile) && FilesEqual(srcFile, dstFile))
                    continue;

                var dstDir = Path.GetDirectoryName(dstFile);
                if (!string.IsNullOrEmpty(dstDir))
                    Directory.CreateDirectory(dstDir);

                try
                {
                    if (File.Exists(dstFile))
                        File.SetAttributes(dstFile, FileAttributes.Normal);
                    File.Copy(srcFile, dstFile, overwrite: true);
                }
                catch (Exception ex)
                {
                    Debug.LogWarning($"[PurrNet] Could not write '{rel}' (may be a locked native library): {ex.Message}");
                    failed++;
                }
            }

            // Remove files that exist in destination but not in source
            foreach (var dstFile in Directory.GetFiles(destination, "*", SearchOption.AllDirectories))
            {
                var rel = Path.GetRelativePath(destination, dstFile);
                if (sourceRelPaths.Contains(rel))
                    continue;

                try
                {
                    File.SetAttributes(dstFile, FileAttributes.Normal);
                    File.Delete(dstFile);
                }
                catch (Exception ex)
                {
                    Debug.LogWarning($"[PurrNet] Could not remove orphaned '{rel}' (may be locked): {ex.Message}");
                    failed++;
                }
            }

            // Prune empty subdirectories bottom-up
            var dirs = Directory.GetDirectories(destination, "*", SearchOption.AllDirectories);
            Array.Sort(dirs, (a, b) => b.Length.CompareTo(a.Length));
            foreach (var dir in dirs)
            {
                try
                {
                    if (Directory.GetFileSystemEntries(dir).Length == 0)
                        Directory.Delete(dir, false);
                }
                catch
                {
                    // not empty or locked — skip
                }
            }

            if (failed > 0)
                Debug.LogWarning($"[PurrNet] Install completed with {failed} file(s) that could not be updated. A Unity restart may be required for native plugin changes to take effect.");
        }

        /// <summary>
        /// Byte-compares two files after a size short-circuit. Chunked read avoids loading
        /// large native DLLs fully into memory.
        /// </summary>
        private static bool FilesEqual(string a, string b)
        {
            var infoA = new FileInfo(a);
            var infoB = new FileInfo(b);
            if (infoA.Length != infoB.Length)
                return false;
            if (infoA.Length == 0)
                return true;

            const int bufSize = 64 * 1024;
            var bufA = new byte[bufSize];
            var bufB = new byte[bufSize];

            using var streamA = new FileStream(a, FileMode.Open, FileAccess.Read, FileShare.Read, bufSize);
            using var streamB = new FileStream(b, FileMode.Open, FileAccess.Read, FileShare.Read, bufSize);

            while (true)
            {
                int readA = ReadFully(streamA, bufA);
                int readB = ReadFully(streamB, bufB);
                if (readA != readB)
                    return false;
                if (readA == 0)
                    return true;
                if (!bufA.AsSpan(0, readA).SequenceEqual(bufB.AsSpan(0, readB)))
                    return false;
            }

            static int ReadFully(FileStream s, byte[] buf)
            {
                int total = 0;
                while (total < buf.Length)
                {
                    int n = s.Read(buf, total, buf.Length - total);
                    if (n == 0) break;
                    total += n;
                }
                return total;
            }
        }

        public static async Task<Result<bool>> Install(string apiKey, PackageInfo package, VersionInfo version, bool resolve = true)
        {
            var backup = ManifestBackup.Capture();
            string installedFolder = null;
            bool installedFolderExisted = false;

            try
            {
                // Git+tag fast path: no download needed, just set manifest to git URL with tag
                if (!package.IsExternal)
                {
                    var gitUrl = GetGitUrlForChannel(package, version.Channel);
                    if (gitUrl != null && !string.IsNullOrEmpty(version.TagName))
                    {
                        EditorUtility.DisplayProgressBar("PurrNet Package Manager", $"Installing {package.DisplayName}...", 0.5f);

                        var gitUpmName = package.GetUpmPackageName();

                        ClearExistingInstall(package, gitUpmName);

                        SetManifestEntry(gitUpmName, StripGitRef(gitUrl) + "#" + version.TagName);

                        EditorUtility.ClearProgressBar();
                        if (resolve)
                        {
                            PurrPackageManagerCache.Invalidate();
                            UnityEditor.PackageManager.Client.Resolve();
                            AssetDatabase.Refresh();
                        }

                        return Result<bool>.Ok(true);
                    }
                }

                EditorUtility.DisplayProgressBar("PurrNet Package Manager", "Getting download URL...", 0.1f);

                var downloadResult = await PurrPackageManagerAPI.GetDownloadUrl(apiKey, package.Id, version.Id);
                if (!downloadResult.Success)
                {
                    EditorUtility.ClearProgressBar();
                    return Result<bool>.Fail(downloadResult.Error);
                }

                EditorUtility.DisplayProgressBar("PurrNet Package Manager", $"Downloading {package.DisplayName}...", 0.3f);

                var downloadFilename = downloadResult.Value.Filename ?? (package.GetUpmPackageName() + ".unitypackage");
                var tempPath = Path.Combine(Path.GetTempPath(), downloadFilename);

                var fileResult = await PurrPackageManagerAPI.DownloadFile(downloadResult.Value.Url, tempPath);
                if (!fileResult.Success)
                {
                    EditorUtility.ClearProgressBar();
                    return Result<bool>.Fail(fileResult.Error);
                }

                EditorUtility.DisplayProgressBar("PurrNet Package Manager", "Installing package...", 0.7f);

                // Extract to a temp directory to read package.json
                var tempExtractDir = Path.Combine("Temp", "PurrNet_extract_" + DateTime.Now.Ticks);

                try
                {
                    ExtractUnityPackage(tempPath, tempExtractDir);
                }
                catch (Exception extractEx)
                {
                    if (Directory.Exists(tempExtractDir))
                        Directory.Delete(tempExtractDir, true);
                    EditorUtility.ClearProgressBar();
                    return Result<bool>.Fail($"Failed to extract package: {extractEx.Message}");
                }

                // Read the real package name and version from package.json
                var pkgJsonPath = Path.Combine(tempExtractDir, "package.json");
                if (!File.Exists(pkgJsonPath))
                {
                    Directory.Delete(tempExtractDir, true);
                    EditorUtility.ClearProgressBar();
                    return Result<bool>.Fail("Extracted package does not contain a package.json");
                }

                var pkgJson = JObject.Parse(await File.ReadAllTextAsync(pkgJsonPath));
                var upmName = pkgJson["name"]?.ToString();
                var upmVersion = pkgJson["version"]?.ToString();

                if (string.IsNullOrEmpty(upmName) || string.IsNullOrEmpty(upmVersion))
                {
                    Directory.Delete(tempExtractDir, true);
                    EditorUtility.ClearProgressBar();
                    return Result<bool>.Fail("package.json is missing 'name' or 'version' field");
                }

                // Remove embedded packages if they exist (Unity prioritizes Packages/{name}/ over manifest)
                var apiName = package.GetUpmPackageName();
                if (HasEmbeddedPackage(apiName) || HasEmbeddedPackage(upmName))
                {
                    EditorUtility.ClearProgressBar();
                    if (!EditorUtility.DisplayDialog("Embedded Package Found",
                        $"An embedded copy of {package.DisplayName} exists in the Packages folder. " +
                        "It must be removed to install the new version. Any local changes will be lost.",
                        "Remove & Continue", "Cancel"))
                    {
                        Directory.Delete(tempExtractDir, true);
                        return Result<bool>.Fail("Installation cancelled by user.");
                    }
                    EditorUtility.DisplayProgressBar("PurrNet Package Manager", "Removing embedded package...", 0.7f);
                }

                installedFolder = Path.Combine("Packages", upmName);
                installedFolderExisted = Directory.Exists(installedFolder);

                InstallFilesSynced(package, upmName, tempExtractDir);

                EditorUtility.DisplayProgressBar("PurrNet Package Manager", "Cleaning up...", 0.9f);

                if (File.Exists(tempPath))
                    File.Delete(tempPath);

                if (Directory.Exists(tempExtractDir))
                    Directory.Delete(tempExtractDir, true);

                EditorUtility.ClearProgressBar();
                if (resolve)
                {
                    PurrPackageManagerCache.Invalidate();
                    UnityEditor.PackageManager.Client.Resolve();
                    AssetDatabase.Refresh();
                }

                return Result<bool>.Ok(true);
            }
            catch (Exception e)
            {
                Debug.LogError($"[PurrNet] Install failed: {e}");
                EditorUtility.ClearProgressBar();

                // Roll back: a partial install must not leave the project worse off than before.
                // Remove any half-written embedded folder we created, then restore manifest/lock.
                if (installedFolder != null && !installedFolderExisted && Directory.Exists(installedFolder))
                    SafeRemoveDirectory(installedFolder);
                backup.Restore();

                if (resolve)
                {
                    PurrPackageManagerCache.Invalidate();
                    try { UnityEditor.PackageManager.Client.Resolve(); } catch { /* lock still held — picked up on next reload */ }
                    AssetDatabase.Refresh();
                }

                return Result<bool>.Fail(e.Message);
            }
        }

        public static bool Remove(PackageInfo package)
        {
            var match = FindInstalledEntry(package);
            if (match == null)
                return false;

            if (!EditorUtility.DisplayDialog("Remove Package",
                $"Are you sure you want to remove {package.DisplayName}?",
                "Remove", "Cancel"))
                return false;

            try
            {
                ClearExistingInstall(package, package.GetUpmPackageName());

                PurrPackageManagerCache.Invalidate();
                UnityEditor.PackageManager.Client.Resolve();
                AssetDatabase.Refresh();
                return true;
            }
            catch (Exception e)
            {
                Debug.LogError($"Failed to remove package: {e.Message}");
                return false;
            }
        }

        public static void InstallExternal(PackageInfo package, string gitUrl, bool resolve = true)
        {
            var backup = ManifestBackup.Capture();
            try
            {
                EditorUtility.DisplayProgressBar("PurrNet Package Manager", $"Installing {package.DisplayName}...", 0.5f);

                var upmName = package.GetUpmPackageName();

                ClearExistingInstall(package, upmName);

                SetManifestEntry(upmName, gitUrl);

                EditorUtility.ClearProgressBar();
                if (resolve)
                {
                    PurrPackageManagerCache.Invalidate();
                    UnityEditor.PackageManager.Client.Resolve();
                    AssetDatabase.Refresh();
                }
            }
            catch (Exception e)
            {
                EditorUtility.ClearProgressBar();
                Debug.LogError($"[PurrNet] Failed to install external package: {e.Message}");

                backup.Restore();
                if (resolve)
                {
                    PurrPackageManagerCache.Invalidate();
                    try { UnityEditor.PackageManager.Client.Resolve(); } catch { /* lock still held — picked up on next reload */ }
                    AssetDatabase.Refresh();
                }
            }
        }

        public static string GetInstalledGitChannel(PackageInfo package)
        {
            var match = FindInstalledEntry(package);
            if (match == null) return "release";
            var value = match.Value.value;
            if (!IsGitUrl(value)) return "release";

            if (!string.IsNullOrEmpty(package.GitInstallUrlDev) && value == package.GitInstallUrlDev)
                return "dev";
            return "release";
        }

        private static bool IsGitUrl(string value)
        {
            return value != null &&
                   (value.StartsWith("https://") || value.StartsWith("git://") || value.StartsWith("git+"));
        }

        /// <summary>
        /// Strips the #fragment from a git URL but preserves ?path= query parameters.
        /// Used when constructing git+tag manifest entries.
        /// </summary>
        private static string StripGitRef(string gitUrl)
        {
            if (gitUrl == null) return "";
            var hashIdx = gitUrl.IndexOf('#');
            return hashIdx >= 0 ? gitUrl.Substring(0, hashIdx) : gitUrl;
        }

        /// <summary>
        /// Picks the appropriate git install URL for a given channel,
        /// falling back to the other channel if the preferred one is null.
        /// </summary>
        private static string GetGitUrlForChannel(PackageInfo package, string channel)
        {
            if (string.Equals(channel, "dev", StringComparison.OrdinalIgnoreCase))
                return package.GitInstallUrlDev ?? package.GitInstallUrlRelease;
            return package.GitInstallUrlRelease ?? package.GitInstallUrlDev;
        }

        /// <summary>
        /// Cleans up old package files in the legacy PurrPackages/ directory for a given UPM name.
        /// Handles both legacy .tgz files and folder-based installs.
        /// Also removes the PurrPackages/ directory itself if it becomes empty.
        /// </summary>
        private static void CleanupLegacyPackageFiles(string upmName)
        {
            if (!Directory.Exists(LegacyPackagesDir)) return;

            // Old tgz files
            foreach (var f in Directory.GetFiles(LegacyPackagesDir, upmName + "-*.tgz"))
            {
                try { File.Delete(f); }
                catch
                {
                    // ignored
                }
            }

            // Folder installs
            foreach (var d in Directory.GetDirectories(LegacyPackagesDir, upmName + "-*"))
            {
                SafeRemoveDirectory(d);
            }

            // Remove PurrPackages/ itself if now empty
            try
            {
                if (Directory.GetFileSystemEntries(LegacyPackagesDir).Length == 0)
                    Directory.Delete(LegacyPackagesDir);
            }
            catch
            {
                // ignored
            }
        }

        /// <summary>
        /// Strips the fragment (#branch/tag/commit) and query string from a git URL
        /// so that URLs pointing to the same repo can be compared regardless of ref.
        /// </summary>
        private static string GetBaseGitUrl(string gitUrl)
        {
            if (gitUrl == null) return "";
            var hashIdx = gitUrl.IndexOf('#');
            if (hashIdx >= 0)
                gitUrl = gitUrl.Substring(0, hashIdx);
            var queryIdx = gitUrl.IndexOf('?');
            if (queryIdx >= 0)
                gitUrl = gitUrl.Substring(0, queryIdx);
            return gitUrl.TrimEnd('/');
        }

        /// <summary>
        /// Extracts a semver version from the #fragment of a git URL (e.g. "...#v1.2.3" -> "1.2.3").
        /// Returns null when the ref is a branch name, commit hash, or otherwise not a version tag.
        /// </summary>
        private static string GetVersionFromGitUrlRef(string gitUrl)
        {
            if (string.IsNullOrEmpty(gitUrl))
                return null;
            var hashIdx = gitUrl.IndexOf('#');
            if (hashIdx < 0 || hashIdx == gitUrl.Length - 1)
                return null;

            var refName = gitUrl.Substring(hashIdx + 1);
            // Tags are conventionally "v{semver}"; tolerate a bare semver too.
            if (refName.Length > 1 && (refName[0] == 'v' || refName[0] == 'V') && char.IsDigit(refName[1]))
                refName = refName.Substring(1);

            // Looks like a version only if it starts with a digit and contains a dot.
            return refName.Length > 0 && char.IsDigit(refName[0]) && refName.Contains('.') ? refName : null;
        }

        /// <summary>
        /// Reads the actual semver version from the resolved package in Library/PackageCache.
        /// When several "<name>@<hash>" folders exist (a stale one lingering after a re-resolve),
        /// prefers the one matching <paramref name="preferredHash"/>, then the most recently written.
        /// </summary>
        private static string GetResolvedPackageVersion(string packageName, string preferredHash = null)
        {
            const string cacheDir = "Library/PackageCache";
            if (!Directory.Exists(cacheDir))
                return null;

            try
            {
                var dirs = Directory.GetDirectories(cacheDir, packageName + "@*");
                if (dirs.Length == 0)
                    return null;

                string chosen = null;
                if (!string.IsNullOrEmpty(preferredHash))
                {
                    foreach (var d in dirs)
                    {
                        var at = Path.GetFileName(d);
                        var atIdx = at.IndexOf('@');
                        if (atIdx >= 0 && string.Equals(at.Substring(atIdx + 1), preferredHash, StringComparison.OrdinalIgnoreCase))
                        {
                            chosen = d;
                            break;
                        }
                    }
                }

                if (chosen == null)
                {
                    chosen = dirs[0];
                    var newest = Directory.GetLastWriteTimeUtc(chosen);
                    for (int i = 1; i < dirs.Length; i++)
                    {
                        var t = Directory.GetLastWriteTimeUtc(dirs[i]);
                        if (t > newest) { newest = t; chosen = dirs[i]; }
                    }
                }

                var pkgJsonPath = Path.Combine(chosen, "package.json");
                if (!File.Exists(pkgJsonPath))
                    return null;

                var json = JObject.Parse(File.ReadAllText(pkgJsonPath));
                return json["version"]?.ToString();
            }
            catch
            {
                return null;
            }
        }

        private static void SetManifestEntry(string packageName, string value)
        {
            try
            {
                var manifest = JObject.Parse(File.ReadAllText(ManifestPath));
                var deps = manifest["dependencies"] as JObject;
                if (deps == null)
                {
                    deps = new JObject();
                    manifest["dependencies"] = deps;
                }
                deps[packageName] = value;
                File.WriteAllText(ManifestPath, manifest.ToString(Formatting.Indented));
                InvalidateFileCaches();
            }
            catch (Exception e)
            {
                Debug.LogError($"[PurrNet] Failed to update manifest.json: {e.Message}");
                throw;
            }
        }

        private static void RemoveManifestEntry(string packageName)
        {
            try
            {
                var manifest = JObject.Parse(File.ReadAllText(ManifestPath));
                var deps = manifest["dependencies"] as JObject;
                if (deps != null && deps.ContainsKey(packageName))
                {
                    deps.Remove(packageName);
                    File.WriteAllText(ManifestPath, manifest.ToString(Formatting.Indented));
                    InvalidateFileCaches();
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"[PurrNet] Failed to update manifest.json: {e.Message}");
                throw;
            }
        }

        private static void ExtractUnityPackage(string packagePath, string targetDir)
        {
            // .unitypackage = gzipped tar
            // Each asset is a folder named by GUID containing:
            //   pathname  - the original asset path
            //   asset     - the file content
            //   asset.meta - the .meta file content

            var entries = new Dictionary<string, PackageEntry>();
            string longName = null;

            using (var fileStream = File.OpenRead(packagePath))
            using (var gzipStream = new GZipStream(fileStream, CompressionMode.Decompress))
            using (var memStream = new MemoryStream())
            {
                gzipStream.CopyTo(memStream);
                var tarBytes = memStream.ToArray();

                int pos = 0;
                while (pos + 512 <= tarBytes.Length)
                {
                    // Check for zero block (end of archive)
                    bool allZero = true;
                    for (int i = 0; i < 512; i++)
                    {
                        if (tarBytes[pos + i] != 0) { allZero = false; break; }
                    }
                    if (allZero) break;

                    // Parse tar header
                    string tarName = Encoding.ASCII.GetString(tarBytes, pos, 100).TrimEnd('\0');
                    string sizeStr = Encoding.ASCII.GetString(tarBytes, pos + 124, 12).Trim('\0', ' ');
                    long size = sizeStr.Length > 0 ? Convert.ToInt64(sizeStr, 8) : 0;
                    char typeFlag = (char)tarBytes[pos + 156];

                    // ustar prefix field (offset 345, 155 bytes)
                    string tarPrefix = Encoding.ASCII.GetString(tarBytes, pos + 345, 155).TrimEnd('\0');
                    if (!string.IsNullOrEmpty(tarPrefix))
                        tarName = tarPrefix + "/" + tarName;

                    pos += 512;

                    byte[] content = null;
                    if (size > 0)
                    {
                        content = new byte[size];
                        Array.Copy(tarBytes, pos, content, 0, (int)size);
                        pos += (int)((size + 511) / 512) * 512;
                    }

                    // Handle GNU long name extension
                    if (typeFlag == 'L')
                    {
                        longName = content != null ? Encoding.ASCII.GetString(content).TrimEnd('\0') : null;
                        continue;
                    }

                    // Use long name if set by previous ././@LongLink entry
                    if (longName != null)
                    {
                        tarName = longName;
                        longName = null;
                    }

                    // Skip pax extended headers
                    if (typeFlag == 'x' || typeFlag == 'g')
                        continue;

                    // Skip directories
                    if (typeFlag == '5')
                        continue;

                    // Strip leading "./"
                    if (tarName.StartsWith("./"))
                        tarName = tarName.Substring(2);

                    // Strip trailing "/"
                    tarName = tarName.TrimEnd('/');

                    // Entries are "{guid}/{type}" where type is pathname, asset, or asset.meta
                    var slashIdx = tarName.IndexOf('/');
                    if (slashIdx < 0)
                        continue;

                    string guid = tarName.Substring(0, slashIdx);
                    string entryName = tarName.Substring(slashIdx + 1);

                    if (!entries.TryGetValue(guid, out var entry))
                    {
                        entry = new PackageEntry();
                        entries[guid] = entry;
                    }

                    if (entryName == "pathname" && content != null)
                        entry.Pathname = Encoding.UTF8.GetString(content).Trim();
                    else if (entryName == "asset")
                        entry.AssetContent = content;
                    else if (entryName == "asset.meta")
                        entry.MetaContent = content;
                }
            }

            // Find the root prefix by locating the shallowest package.json
            string rootPrefix = null;
            foreach (var entry in entries.Values)
            {
                if (entry.Pathname == null)
                    continue;

                var fn = entry.Pathname;
                // Normalize slashes
                fn = fn.Replace('\\', '/');
                entry.Pathname = fn;

                if (fn.EndsWith("/package.json") || fn == "package.json")
                {
                    var prefix = fn.Substring(0, fn.Length - "package.json".Length);
                    if (rootPrefix == null || prefix.Length < rootPrefix.Length)
                        rootPrefix = prefix;
                }
            }

            // Fallback: find the shortest common directory prefix
            if (rootPrefix == null)
            {
                foreach (var entry in entries.Values)
                {
                    if (entry.Pathname == null)
                        continue;
                    var lastSlash = entry.Pathname.LastIndexOf('/');
                    var dir = lastSlash >= 0 ? entry.Pathname.Substring(0, lastSlash + 1) : "";
                    if (rootPrefix == null || dir.Length < rootPrefix.Length)
                        rootPrefix = dir;
                }
            }

            rootPrefix ??= "";

            // Write files to target directory
            Directory.CreateDirectory(targetDir);
            int fileCount = 0;

            foreach (var entry in entries.Values)
            {
                if (entry.Pathname == null)
                    continue;

                // Skip entries that are parent directories of the root prefix
                // e.g., "Assets" or "Assets/SomePlugin" when rootPrefix is "Assets/SomePlugin/"
                if (rootPrefix.Length > 0 && rootPrefix.StartsWith(entry.Pathname + "/"))
                    continue;

                // Strip root prefix
                string relativePath = entry.Pathname;
                if (rootPrefix.Length > 0 && relativePath.StartsWith(rootPrefix))
                    relativePath = relativePath.Substring(rootPrefix.Length);

                if (string.IsNullOrEmpty(relativePath))
                    continue;

                // Write asset content
                if (entry.AssetContent != null)
                {
                    var fullPath = Path.Combine(targetDir, relativePath);
                    var dir = Path.GetDirectoryName(fullPath);
                    if (!string.IsNullOrEmpty(dir))
                        Directory.CreateDirectory(dir);
                    File.WriteAllBytes(fullPath, entry.AssetContent);
                    fileCount++;
                }

                // Write .meta file
                if (entry.MetaContent != null)
                {
                    var metaPath = Path.Combine(targetDir, relativePath + ".meta");
                    var dir = Path.GetDirectoryName(metaPath);
                    if (!string.IsNullOrEmpty(dir))
                        Directory.CreateDirectory(dir);
                    File.WriteAllBytes(metaPath, entry.MetaContent);
                }
            }

            if (fileCount == 0)
                Debug.LogWarning("[PurrNet] Package extraction produced no files.");
        }

        private class PackageEntry
        {
            public string Pathname;
            public byte[] AssetContent;
            public byte[] MetaContent;
        }
    }
}
